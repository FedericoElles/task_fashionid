'use strict';
var Q = require('q');


var fs = require('fs');
var promiseReadFile = Q.denodeify(fs.readFile);
 
var express = require('express');
var app = express(); 



var Converter = require("csvtojson").core.Converter;
var csvConverter = new Converter({});
var promiseCsvConverter = Q.nbind(csvConverter.fromString, csvConverter);

var helper = require('./helper.js'); 
 

/* 
  CONFIG
*/ 

var FILE = 'addressbook.csv';
var HEADER = 'name, gender, birthday'; // CSV header

// Look ma, no global variables!





/*
 * START 
 */

// Read static data 
promiseReadFile(FILE)
  // Add Header to make it real CSV file
  .then(function(data){
    return HEADER + '\n' + data.toString();
  })
  // Convert CSV into JS object
  .then(promiseCsvConverter)
  // Convert birthday string into date
  .then(function(jsonObj){
  
    for (var rec in jsonObj){
      jsonObj[rec].birthday = helper.dmyStringToDate(jsonObj[rec].birthday)
    };
    console.log(jsonObj);
    return jsonObj;
  })
  // Answer questions
  .then(function(jsonObj){
    var answers = {
      1: 'unknown',
      2: 'unknown',
      3: 'unknown'    
    }; 
    // TODO: process questins
    // 1: https://github.com/agershun/alasql/wiki/Count
    // 2: https://github.com/agershun/alasql/wiki/Min
    return answers;
  })
  // Start Server  
  .then(function(answers){

    /**
     * The output format of any question should be like this:
     * <question number>. <answer><new line>
     * @param id - key to the ANSWERS object
     * @returns {String} - formatted answer 
     */  
    function getFormattedAnswer(id){
      return id + '. ' + answers[id]+ '\n'; 
    } 

    // All answers
    app.get('/questions', function (req, res) {
      res.type('text/plain'); // set content-type
      var allAnswers = '';
      for (var answerId in answers){
        allAnswers += getFormattedAnswer(answerId);
      }   
      res.send(allAnswers); // send text response
    }); 
    
    // Single answers
    app.get('/questions/:id', function (req, res) {
      res.type('text/plain'); // set content-type 
      res.send(getFormattedAnswer(req.params.id)); // send text response
    });  
    
    // Start Server
    var server = app.listen(3000, function () {
      var host = server.address().address;
      var port = server.address().port;
      console.log('Example app listening at http://%s:%s', host, port);
    });
  
  })
  .fail(function(err){
    console.log('error', err);
  });
 
 // Make app available to test framework
if (module.parent){
  module.exports = app;
}