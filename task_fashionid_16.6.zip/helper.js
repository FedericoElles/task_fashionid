'use strict';

var helper = {};

// convert date string to javascript date
// via http://stackoverflow.com/questions/19709793/convert-date-from-dd-mm-yyyy-to-yyyy-mm-dd-in-javascript
helper.dmyStringToDate = function(date){
  var newdate = '19' + date.split('/').reverse().join('-');
  return new Date(newdate);
}

module.exports = helper;